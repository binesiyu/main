ex-cscope
=========

easy to use cscope for exvim
