foreign import ccall unsafe "math.h sin"
  c_sin :: CDouble -> CDouble
