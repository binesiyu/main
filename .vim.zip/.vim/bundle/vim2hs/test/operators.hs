qual = 1 Prelude.+ 2

norm = 1 + 2
