module Main where

compileError =

main = return ()
