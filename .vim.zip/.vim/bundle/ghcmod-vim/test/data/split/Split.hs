module Split (f) where

f :: [a] -> a
f x = undefined
