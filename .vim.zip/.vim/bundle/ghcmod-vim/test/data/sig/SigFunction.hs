module SigFunction where

func :: [a] -> Maybe b -> (a -> b) -> (a,b)
