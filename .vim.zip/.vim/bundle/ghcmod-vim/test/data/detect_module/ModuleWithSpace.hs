      module   ModuleWithSpace  where

moduleWithSpace :: Char
moduleWithSpace = ' '
