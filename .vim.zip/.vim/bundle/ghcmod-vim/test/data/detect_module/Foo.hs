module Foo (foo) where

foo :: Int
foo = 42
