#!/bin/bash
export DEST="./.exvim.vim"
export TOOLS="/Users/yubin/.vim/tools/"
export IS_EXCLUDE=-not
export FOLDERS=""
export FILE_SUFFIXS=".*"
export TMP="${DEST}/_files"
export TARGET="${DEST}/files"
export ID_TARGET="${DEST}/idutils-files"
bash ${TOOLS}/shell/bash/update-filelist.sh
