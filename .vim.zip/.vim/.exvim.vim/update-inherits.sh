#!/bin/bash
export DEST="./.exvim.vim"
export TOOLS="/Users/yubin/.vim/tools/"
export TMP="${DEST}/_inherits"
export TARGET="${DEST}/inherits"
sh ${TOOLS}/shell/bash/update-inherits.sh
