#!/bin/bash
export DEST="./.exvim.vim"
export TOOLS="/Users/yubin/.vim/tools/"
export TMP="${DEST}/_ID"
export TARGET="${DEST}/ID"
sh ${TOOLS}/shell/bash/update-idutils.sh
