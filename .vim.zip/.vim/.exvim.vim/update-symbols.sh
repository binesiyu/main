#!/bin/bash
export DEST="./.exvim.vim"
export TOOLS="/Users/yubin/.vim/tools/"
export TMP="${DEST}/_symbols"
export TARGET="${DEST}/symbols"
sh ${TOOLS}/shell/bash/update-symbols.sh
